# from flask import Flask, request, jsonify
# from datetime import datetime, timedelta

# app = Flask(__name__)

# @app.route('/analyze-study-plan', methods=['POST'])
# def analyze_study_plan():
#     data = request.get_json()

#     # Extract input
#     subjects = data.get('subjects', [])
#     hours = int(data.get('daily_hours', 0))
#     exam_date = data.get('exam_date', 'not set')
#     difficulty = data.get('difficulty', 'medium').lower()

#     # Simulated AI Suggestions (dynamic)
#     suggestions = []

#     if not subjects:
#         suggestions.append("Add at least one subject to generate a proper plan.")
#     else:
#         suggestions.append(f"Focus more on your weaker subject: {subjects[0]}.")

#     if hours < 2:
#         suggestions.append("Consider increasing study hours to at least 2 per day.")
#     elif hours >= 5:
#         suggestions.append("You're putting in great hours—ensure to take breaks to avoid burnout.")
#     else:
#         suggestions.append("Maintain consistency in your study schedule.")

#     if difficulty == "hard":
#         suggestions.append("Break tough topics into small chunks and revise frequently.")
#     elif difficulty == "easy":
#         suggestions.append("stay consistent; don't get too relaxed with easy topics.")
#     else:
#         suggestions.append("Gradually increase complexity in topics over time.")

#     # Format exam date for revision advice
#     try:
#         exam = datetime.strptime(exam_date, "%Y-%m-%d")
#         revision_start = exam - timedelta(weeks=2)
#         suggestions.append(f"Start revising at least 2 weeks before: {revision_start.strftime('%Y-%m-%d')}")
#     except ValueError:
#         suggestions.append("Invalid exam date format. Use YYYY-MM-DD.")

#     # Build response
#     response = f"""
# Based on your input:
# Subjects: {', '.join(subjects) if subjects else 'None'}
# Daily Study Hours: {hours}
# Difficulty Level: {difficulty.capitalize()}

# 💡 AI Suggestions:
# - {chr(10).join(suggestions)}
# """

#     return jsonify({
#         "ai_advice": response.strip()
#     })

# if __name__ == '__main__':
#     app.run(port=5000)

from flask import Flask, request, jsonify
from datetime import datetime, timedelta
import google.generativeai as genai

app = Flask(__name__)

# === Gemini v1 API Key ===
genai.configure(api_key="AIzaSyB2wNZBnEus9RQV7lUMJMxnVo-bwSEXNU0")

# === AI Endpoint ===
@app.route('/analyze-study-plan', methods=['POST'])
def analyze_study_plan():
    data = request.get_json()

    subjects = data.get('subjects', [])
    hours = int(data.get('daily_hours', 0))
    exam_date = data.get('exam_date', 'not set')
    difficulty = data.get('difficulty', 'medium').lower()

    # Prompt to send to Gemini
    prompt = f"""
You are an educational AI mentor.
Analyze this user's study preferences and suggest personalized study techniques and improvements.

Subjects: {', '.join(subjects) if subjects else 'None'}
Daily Hours: {hours}
Exam Date: {exam_date}
Difficulty Level: {difficulty}

💡 Format: Provide 4-5 bullet points of actionable advice.
"""

    try:
        # ✅ Use a valid v1 model name
        model = genai.GenerativeModel("gemini-1.5-flash")  # Or gemini-1.5-pro for heavier responses
        response = model.generate_content(prompt)
        ai_advice = response.text.strip()
    except Exception as e:
        ai_advice = f"⚠️ Gemini error: {e}"

    return jsonify({
        "ai_advice": ai_advice
    })

if __name__ == '__main__':
    app.run(port=5000)
