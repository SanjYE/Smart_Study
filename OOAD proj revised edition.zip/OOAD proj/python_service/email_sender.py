import smtplib
import sys
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication

def send_email(recipient_email):
    # Email credentials
    sender_email = "shashank.bakshi03@gmail.com"
    sender_password = "gygz rijm xuww txrs"  # Gmail app password

    # Setup the email
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = recipient_email
    message["Subject"] = "Your Smart Study Plan PDF"

    # Email body
    body = "Hi there!\n\nAttached is your personalized study plan PDF. Let's crush those exams! "
    message.attach(MIMEText(body, "plain"))

    # 📎 Attach the PDF
    pdf_path = r"C:\Users\shash\OneDrive\Desktop\OOAD proj\bridge\study_plan.pdf"
    print(f" Looking for PDF at: {pdf_path}")
    print(f" Current working directory: {os.getcwd()}")

    if os.path.exists(pdf_path):
        with open(pdf_path, "rb") as file:
            part = MIMEApplication(file.read(), Name=os.path.basename(pdf_path))
            part['Content-Disposition'] = f'attachment; filename="{os.path.basename(pdf_path)}"'
            message.attach(part)
    else:
        print("PDF not found. Email not sent.")
        return

    # Send email via Gmail SMTP server
    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.send_message(message)
        server.quit()
        print(f"Email sent to {recipient_email}!")
    except Exception as e:
        print("Failed to send email:", str(e))

# =========================
# Entry point from Java
# =========================
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python email_sender.py <recipient_email>")
    else:
        send_email(sys.argv[1])
