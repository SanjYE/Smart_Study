# import json
# import os
# from fpdf import FPDF

# # Use absolute path to the JSON file
# json_path = os.path.abspath("C:\\Users\\shash\\OneDrive\\Desktop\\OOAD proj\\bridge\\study_plan.json")
# pdf_path = os.path.abspath("C:\\Users\\shash\\OneDrive\\Desktop\\OOAD proj\\pdf_collection\\study_plan.pdf")

# # Load the study plan
# with open(json_path, 'r') as file:
#     study_plan = json.load(file)

# # Create a PDF
# pdf = FPDF()
# pdf.add_page()
# pdf.set_font("Arial", size=12)
# pdf.cell(200, 10, txt="Smart Study Plan", ln=True, align='C')
# pdf.ln(10)

# for day, tasks in study_plan.items():
#     pdf.set_font("Arial", style='B', size=12)
#     pdf.cell(200, 10, txt=f"{day}:", ln=True)
#     pdf.set_font("Arial", size=12)
#     for task in tasks:
#         pdf.cell(200, 10, txt=f"  - {task}", ln=True)
#     pdf.ln(5)

# # Save PDF
# pdf.output(pdf_path)
# print(f"✅ PDF created successfully at '{pdf_path}'")

from fpdf import FPDF
import json
import os
import re

# === 🔧 Emoji sanitizer ===
def remove_unicode_emojis(text):
    return re.sub(r'[^\x00-\x7F]+', '', text)

# === 📥 Load metadata and study plan ===
bridge_dir = "bridge"
pdf_path = os.path.join(bridge_dir, "StudyPlan.pdf")

with open(os.path.join(bridge_dir, "metadata.json"), "r") as f:
    metadata = json.load(f)

with open(os.path.join(bridge_dir, "study_plan.json"), "r") as f:
    study_plan = json.load(f)

# === 📄 Generate PDF ===
pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)

pdf.cell(200, 10, txt=remove_unicode_emojis("Personalized Study Plan"), ln=True, align='C')
pdf.ln(10)

# Metadata
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, txt="Student Info:", ln=True)
pdf.set_font("Arial", size=12)

for key, value in metadata.items():
    line = f"{key.capitalize()}: {value}"
    pdf.cell(200, 10, txt=remove_unicode_emojis(line), ln=True)

pdf.ln(10)
pdf.set_font("Arial", "B", 12)
pdf.cell(200, 10, txt="Study Plan:", ln=True)
pdf.set_font("Arial", size=12)

# Study plan
for day, tasks in study_plan.items():
    pdf.set_font("Arial", "B", 12)
    pdf.cell(200, 10, txt=remove_unicode_emojis(day), ln=True)
    pdf.set_font("Arial", size=12)
    for task in tasks:
        pdf.cell(200, 10, txt=remove_unicode_emojis(f"- {task}"), ln=True)
    pdf.ln(5)

pdf.output(pdf_path)
print("PDF generated at:", pdf_path)
