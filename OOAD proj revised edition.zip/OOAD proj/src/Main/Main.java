// package src.Main;

// import src.module1_profile.*;
// import src.module2_AI_Engine.*;
// import src.Module3_Progress.*;
// import src.Module4_UI_Notifications.*;

// import java.util.*;

// public class Main {

//     public static void main(String[] args) {
//         Scanner sc = new Scanner(System.in);

//         System.out.println("📚 Welcome to Smart Study Planner!");
//         System.out.print("Enter your name: ");
//         String name = sc.nextLine();

//         System.out.print("Enter your email: ");
//         String email = sc.nextLine();

//         System.out.print("Enter subjects (comma separated): ");
//         String[] subjects = sc.nextLine().split(",");

//         System.out.print("How many hours can you study daily? ");
//         int dailyStudyHours = Integer.parseInt(sc.nextLine());

//         System.out.print("Enter your exam date (YYYY-MM-DD): ");
//         String examDate = sc.nextLine();

//         System.out.print("Choose difficulty level (easy/medium/hard): ");
//         String difficulty = sc.nextLine();

//         Student student = new Student(name, email);
//         Preferences prefs = new Preferences(subjects, dailyStudyHours, examDate, difficulty);

//         // 🔥 AI ADVICE (via Python microservice)
//         System.out.println("\nFetching smart advice from your AI mentor...\n");
//         String aiAdvice = AIServiceClient.getAIAdvice(subjects, dailyStudyHours, examDate, difficulty);
//         System.out.println("AI Mentor Says:\n" + aiAdvice + "\n");

//         ProfileManager profileManager = new ProfileManager();
//         profileManager.editProfile(student, prefs);
//         profileManager.viewProfile(student);

//         ReminderManager reminderManager = new ReminderManager();
//         reminderManager.addReminder("Start studying by 7 PM every day");
//         reminderManager.showReminders();

//         // === MODULE 2: Generate AI Study Plan ===
//         Preferences preferences = student.getPreferences();
//         Map<String, List<String>> studyPlan = null;

//         if (preferences == null) {
//             System.out.println("⚠️ Cannot generate study plan: Preferences not set.");
//         } else {
//             StudyPlanGenerator studyPlanGenerator = new StudyPlanGenerator(preferences);
//             studyPlan = studyPlanGenerator.generatePlan();

//             AI_Engine aiEngine = new AI_Engine();
//             aiEngine.optimizePlan(studyPlan, preferences.getDifficultyLevel());

//             FeedbackManager feedbackManager = new FeedbackManager();
//             String feedback = "too much content";
//             feedbackManager.modifyPlanBasedOnFeedback(studyPlan, feedback);

//             studyPlanGenerator.displayPlan(studyPlan);
//         }

//         // === MODULE 3: Progress Tracker ===
//         ProgressTracker tracker = new ProgressTracker(studyPlan);
//         AnalyticsEngine analytics = new AnalyticsEngine();
//         PlanUpdater updater = new PlanUpdater();

//         Scanner topicScanner = new Scanner(System.in);
//         System.out.println("\nWould you like to mark any topic as completed? (yes/no)");
//         String response = topicScanner.nextLine().trim().toLowerCase();

//         while (response.equals("yes")) {
//             System.out.print("Enter the day (e.g., Day 1): ");
//             String day = topicScanner.nextLine().trim();

//             System.out.print("Enter the topic (e.g., Study: Math): ");
//             String topic = topicScanner.nextLine().trim();

//             tracker.markTopicCompleted(day, topic);

//             System.out.print("Mark another topic? (yes/no): ");
//             response = topicScanner.nextLine().trim().toLowerCase();
//         }

//         analytics.generateReport(tracker.getCompletedTopics(), tracker.getPendingTopics());
//         analytics.displayPerformanceGraph(tracker.getCompletedTopics(), tracker.getPendingTopics());
//         updater.updatePlanBasedOnProgress(tracker.getPendingTopics(), studyPlan);

//         // === MODULE 4: UI + Python Export + Email ===
//         if (studyPlan != null) {
//             UserInterface ui = new UserInterface();
//             Notification_Service notifier = new Notification_Service();
//             Exporter exporter = new Exporter();

//             ui.displayStudyPlan(studyPlan);
//             ui.markTopicAsCompleted(studyPlan, "Day 1", "Study: Physics");

//             notifier.addReminder("Finish your Physics topic today!");
//             notifier.addReminder("Revise Math by tomorrow morning.");
//             notifier.sendReminders();

//             // 📤 Automatically export to JSON + trigger Python PDF service
//             System.out.println("\n🔄 Generating PDF from your study plan...");
//             exporter.exportToPDF(studyPlan);

//             // 📧 Sending email with attached PDF
//             System.out.println("\n📧 Sending your personalized plan to: " + email);
//             exporter.sendViaEmail(email, studyPlan);
//         } else {
//             System.out.println("⚠️ Study plan not available. UI & Notifications skipped.");
//         }

//         // 💡 Clean up scanner objects
//         sc.close();
//         topicScanner.close();
//     }
// }

package src.Main;

import src.module1_profile.*;
import src.module2_AI_Engine.*;
import src.Module3_Progress.*;
import src.Module4_UI_Notifications.*;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("📚 Welcome to Smart Study Planner!");
        System.out.print("Enter your name: ");
        String name = sc.nextLine();

        System.out.print("Enter your email: ");
        String email = sc.nextLine();

        System.out.print("Enter subjects (comma separated): ");
        String[] subjects = sc.nextLine().split(",");

        System.out.print("How many hours can you study daily? ");
        int dailyStudyHours = Integer.parseInt(sc.nextLine());

        System.out.print("Enter your exam date (YYYY-MM-DD): ");
        String examDate = sc.nextLine();

        System.out.print("Choose difficulty level (easy/medium/hard): ");
        String difficulty = sc.nextLine();

        Student student = new Student(name, email);
        Preferences prefs = new Preferences(subjects, dailyStudyHours, examDate, difficulty);
        student.setPreferences(prefs);

        // 🔥 AI ADVICE (via Python microservice)
        System.out.println("\n🤖 Fetching smart advice from your AI mentor...\n");
        String aiAdvice = AIServiceClient.getAIAdvice(subjects, dailyStudyHours, examDate, difficulty);
        System.out.println("🧠 AI Mentor Says:\n" + aiAdvice + "\n");

        ProfileManager profileManager = new ProfileManager();
        profileManager.editProfile(student, prefs);
        profileManager.viewProfile(student);

        ReminderManager reminderManager = new ReminderManager();
        reminderManager.addReminder("Start studying by 7 PM every day");
        reminderManager.showReminders();

        // === MODULE 2: Generate AI Study Plan ===
        Preferences preferences = student.getPreferences();
        Map<String, List<String>> studyPlan = null;

        if (preferences == null) {
            System.out.println("⚠️ Cannot generate study plan: Preferences not set.");
        } else {
            StudyPlanGenerator studyPlanGenerator = new StudyPlanGenerator(preferences);
            studyPlan = studyPlanGenerator.generatePlan();

            AI_Engine aiEngine = new AI_Engine();
            aiEngine.optimizePlan(studyPlan, preferences.getDifficultyLevel());

            FeedbackManager feedbackManager = new FeedbackManager();
            String feedback = "too much content"; // placeholder feedback
            feedbackManager.modifyPlanBasedOnFeedback(studyPlan, feedback);

            studyPlanGenerator.displayPlan(studyPlan);
        }

        // === MODULE 3: Progress Tracker ===
        ProgressTracker tracker = new ProgressTracker(studyPlan);
        AnalyticsEngine analytics = new AnalyticsEngine();
        PlanUpdater updater = new PlanUpdater();

        Scanner topicScanner = new Scanner(System.in);
        System.out.println("\nWould you like to mark any topic as completed? (yes/no)");
        String response = topicScanner.nextLine().trim().toLowerCase();

        while (response.equals("yes")) {
            System.out.print("Enter the day (e.g., Day 1): ");
            String day = topicScanner.nextLine().trim();

            System.out.print("Enter the topic (e.g., Study: Math): ");
            String topic = topicScanner.nextLine().trim();

            tracker.markTopicCompleted(day, topic);

            System.out.print("Mark another topic? (yes/no): ");
            response = topicScanner.nextLine().trim().toLowerCase();
        }

        analytics.generateReport(tracker.getCompletedTopics(), tracker.getPendingTopics());
        analytics.displayPerformanceGraph(tracker.getCompletedTopics(), tracker.getPendingTopics());
        updater.updatePlanBasedOnProgress(tracker.getPendingTopics(), studyPlan);

        // === MODULE 4: UI + Export to Python + Email ===
        if (studyPlan != null) {
            UserInterface ui = new UserInterface();
            Notification_Service notifier = new Notification_Service();
            Exporter exporter = new Exporter();

            ui.displayStudyPlan(studyPlan);
            ui.markTopicAsCompleted(studyPlan, "Day 1", "Study: Physics");

            notifier.addReminder("Finish your Physics topic today!");
            notifier.addReminder("Revise Math by tomorrow morning.");
            notifier.sendReminders();

            // 📤 Export data for PDF generation
            exporter.exportToBridgeFiles(student, studyPlan);

            // 🖨️ Generate PDF using Python microservice
            exporter.generatePDF();

            // 📧 Send PDF via email
            exporter.sendViaEmail(email);
        } else {
            System.out.println("⚠️ Study plan not available. UI & Notifications skipped.");
        }

        // Cleanup
        sc.close();
        topicScanner.close();
    }
}

