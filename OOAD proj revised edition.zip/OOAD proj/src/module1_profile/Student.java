package src.module1_profile;

import java.util.ArrayList;
import java.util.List;

public class Student {
    private String name;
    private String email;
    private Preferences preferences;
    private List<String> pastStudyPlans;

    public Student(String name, String email) {
        this.name = name;
        this.email = email;
        this.pastStudyPlans = new ArrayList<>();
    }

    public void setPreferences(Preferences preferences) {
        this.preferences = preferences;
    }

    public Preferences getPreferences() {
        return preferences;
    }

    public void addPastStudyPlan(String planSummary) {
        pastStudyPlans.add(planSummary);
    }

    public List<String> getPastStudyPlans() {
        return pastStudyPlans;
    }

    public void viewPastPlans() {
        System.out.println("=== Past Study Plans ===");
        for (String plan : pastStudyPlans) {
            System.out.println(plan);
        }
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
}
