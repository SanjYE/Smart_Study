// package src.module1_profile;

// public class Preferences {
//     private String[] subjects;
//     private int dailyStudyHours;
//     private String examDate;
//     private String difficultyLevel;

//     public Preferences(String[] subjects, int dailyStudyHours, String examDate, String difficultyLevel) {
//         this.subjects = subjects;
//         this.dailyStudyHours = dailyStudyHours;
//         this.examDate = examDate;
//         this.difficultyLevel = difficultyLevel;
//     }

//     public String[] setSubjects() {
//         return subjects;
//     }

//     public int setDailyStudyHours() {
//         return dailyStudyHours;
//     }

//     public String setExamDate() {
//         return examDate;
//     }

//     public String setDifficultyLevel() {
//         return difficultyLevel;
//     }

//     public void display() {
//         System.out.println("Subjects: ");
//         for (String subject : subjects) {
//             System.out.println(" - " + subject);
//         }
//         System.out.println("Daily Study Hours: " + dailyStudyHours);
//         System.out.println("Exam Date: " + examDate);
//         System.out.println("Difficulty Level: " + difficultyLevel);
//     }
// }

package src.module1_profile;

public class Preferences {
    private String[] subjects;
    private int dailyStudyHours;
    private String examDate;
    private String difficultyLevel;

    public Preferences(String[] subjects, int dailyStudyHours, String examDate, String difficultyLevel) {
        this.subjects = subjects;
        this.dailyStudyHours = dailyStudyHours;
        this.examDate = examDate;
        this.difficultyLevel = difficultyLevel;
    }

    // ✅ Getters (correct naming and usage)
    public String[] getSubjects() {
        return subjects;
    }

    public int getDailyStudyHours() {
        return dailyStudyHours;
    }

    public String getExamDate() {
        return examDate;
    }

    public String getDifficultyLevel() {
        return difficultyLevel;
    }

    // Optional: Setters if you want to allow updating values later
    public void setSubjects(String[] subjects) {
        this.subjects = subjects;
    }

    public void setDailyStudyHours(int hours) {
        this.dailyStudyHours = hours;
    }

    public void setExamDate(String date) {
        this.examDate = date;
    }

    public void setDifficultyLevel(String level) {
        this.difficultyLevel = level;
    }

    public void display() {
        System.out.println("Subjects: ");
        for (String subject : subjects) {
            System.out.println(" - " + subject);
        }
        System.out.println("Daily Study Hours: " + dailyStudyHours);
        System.out.println("Exam Date: " + examDate);
        System.out.println("Difficulty Level: " + difficultyLevel);
    }
}
