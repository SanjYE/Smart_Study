package src.module1_profile;

public class ProfileManager {

    public void editProfile(Student student, Preferences newPreferences) {
        student.setPreferences(newPreferences);
        System.out.println("Profile updated successfully.");
    }

    public void viewProfile(Student student) {
        System.out.println("=== Profile for " + student.getName() + " ===");
        System.out.println("Email: " + student.getEmail());
        if (student.getPreferences() != null) {
            student.getPreferences().display();
        } else {
            System.out.println("No preferences set.");
        }
    }
}
