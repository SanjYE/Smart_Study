package src.module1_profile;
import java.util.ArrayList;
import java.util.List;

public class ReminderManager {
    private List<String> reminders = new ArrayList<>();

    public void addReminder(String reminderText) {
        reminders.add(reminderText);
        System.out.println("Reminder added: " + reminderText);
    }

    public void showReminders() {
        System.out.println("=== Reminders ===");
        for (String r : reminders) {
            System.out.println(" - " + r);
        }
    }
}
