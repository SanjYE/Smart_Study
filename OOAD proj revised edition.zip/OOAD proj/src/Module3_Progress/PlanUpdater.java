package src.Module3_Progress;

import java.util.*;

public class PlanUpdater {

    public void updatePlanBasedOnProgress(Map<String, List<String>> pending, Map<String, List<String>> studyPlan) {
        System.out.println("\nUpdating plan based on pending topics...");

        for (String day : pending.keySet()) {
            List<String> extra = pending.get(day);
            if (!extra.isEmpty()) {
                // Move these to next day or append in same
                String nextDay = "Day " + (Integer.parseInt(day.split(" ")[1]) + 1);
                if (studyPlan.containsKey(nextDay)) {
                    studyPlan.get(nextDay).addAll(extra);
                } else {
                    studyPlan.put(nextDay, new ArrayList<>(extra));
                }
                System.out.println("Moved " + extra.size() + " pending tasks from " + day + " to " + nextDay);
            }
        }
    }
}
