package src.Module3_Progress;

import java.util.*;

public class AnalyticsEngine {

    public void generateReport(Map<String, List<String>> completed, Map<String, List<String>> pending) {
        System.out.println("\n=== Study Progress Report ===");

        for (String day : completed.keySet()) {
            int total = completed.get(day).size() + pending.get(day).size();
            int done = completed.get(day).size();
            int percent = (total == 0) ? 0 : (done * 100) / total;

            System.out.println(day + ": " + percent + "% completed [" + done + "/" + total + "]");
        }
    }

    public void displayPerformanceGraph(Map<String, List<String>> completed, Map<String, List<String>> pending) {
        System.out.println("\n=== Performance Graph ===");
        for (String day : completed.keySet()) {
            int total = completed.get(day).size() + pending.get(day).size();
            int done = completed.get(day).size();
            int percent = (total == 0) ? 0 : (done * 100) / total;

            System.out.print(day + " | ");
            for (int i = 0; i < percent / 10; i++) {
                System.out.print("█");
            }
            System.out.println(" " + percent + "%");
        }
    }
}
