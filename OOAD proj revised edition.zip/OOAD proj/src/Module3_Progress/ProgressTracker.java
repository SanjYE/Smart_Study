package src.Module3_Progress;

import java.util.*;

public class ProgressTracker {

    private Map<String, List<String>> completedTopics;
    private Map<String, List<String>> pendingTopics;

    public ProgressTracker(Map<String, List<String>> studyPlan) {
        this.completedTopics = new HashMap<>();
        this.pendingTopics = new HashMap<>();

        // Clone study plan as pending initially
        for (String day : studyPlan.keySet()) {
            pendingTopics.put(day, new ArrayList<>(studyPlan.get(day)));
            completedTopics.put(day, new ArrayList<>());
        }
    }

    public void markTopicCompleted(String day, String topic) {
        List<String> pending = pendingTopics.get(day);
        List<String> completed = completedTopics.get(day);

        if (pending != null && pending.contains(topic)) {
            pending.remove(topic);
            completed.add(topic);
            System.out.println("Marked as completed: " + topic + " on " + day);
        } else {
            System.out.println("Topic not found in pending list.");
        }
    }

    public Map<String, List<String>> getCompletedTopics() {
        return completedTopics;
    }

    public Map<String, List<String>> getPendingTopics() {
        return pendingTopics;
    }
}
