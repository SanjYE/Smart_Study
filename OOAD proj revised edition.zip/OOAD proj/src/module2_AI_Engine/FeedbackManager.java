package src.module2_AI_Engine;

import java.util.Map;
import java.util.List;

public class FeedbackManager {

    public void modifyPlanBasedOnFeedback(Map<String, List<String>> plan, String feedback) {
        if (feedback.toLowerCase().contains("too much")) {
            System.out.println("Feedback Response: Reducing daily load slightly...");
            for (List<String> tasks : plan.values()) {
                if (tasks.size() > 1) {
                    tasks.remove(tasks.size() - 1); // Remove last task of each day
                }
            }
        } else if (feedback.toLowerCase().contains("too easy")) {
            System.out.println("Feedback Response: Adding advanced tasks...");
            for (List<String> tasks : plan.values()) {
                tasks.add(" - Extra Practice: Advanced Problems");
            }
        } else {
            System.out.println("Feedback Response: No significant changes made.");
        }
    }
}
