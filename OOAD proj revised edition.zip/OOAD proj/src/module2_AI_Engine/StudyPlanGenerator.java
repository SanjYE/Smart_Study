package src.module2_AI_Engine;

import src.module1_profile.Preferences;
import java.util.*;

public class StudyPlanGenerator {

    private Preferences preferences;

    public StudyPlanGenerator(Preferences preferences) {
        this.preferences = preferences;
    }

    public Map<String, List<String>> generatePlan() {
        Map<String, List<String>> studyPlan = new HashMap<>();
        String[] subjects = preferences.getSubjects();
        int days = 7; // Default week-based plan

        for (int i = 0; i < days; i++) {
            String day = "Day " + (i + 1);
            List<String> daySubjects = new ArrayList<>();

            // Rotate subjects for simplicity
            for (int j = 0; j < preferences.getDailyStudyHours(); j++) {
                String subject = subjects[(i + j) % subjects.length];
                daySubjects.add("Study: " + subject);
            }

            studyPlan.put(day, daySubjects);
        }

        return studyPlan;
    }

    public void displayPlan(Map<String, List<String>> plan) {
        System.out.println("=== Generated Study Plan ===");
        for (String day : plan.keySet()) {
            System.out.println(day + ":");
            for (String task : plan.get(day)) {
                System.out.println(" - " + task);
            }
        }
    }
}
