// File: AIServiceClient.java
package src.module2_AI_Engine;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AIServiceClient {

    public static String getAIAdvice(String[] subjects, int hours, String examDate, String difficulty) {
        try {
            URL url = new URL("http://127.0.0.1:5000/analyze-study-plan");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json; utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);

            // Convert subject array to JSON array string
            StringBuilder subjectJsonArray = new StringBuilder("[");
            for (int i = 0; i < subjects.length; i++) {
                subjectJsonArray.append("\"").append(subjects[i].trim()).append("\"");
                if (i != subjects.length - 1) subjectJsonArray.append(",");
            }
            subjectJsonArray.append("]");

            String jsonInputString = String.format(
                    "{\"subjects\": %s, \"daily_hours\": %d, \"exam_date\": \"%s\", \"difficulty\": \"%s\"}",
                    subjectJsonArray, hours, examDate, difficulty
            );

            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            StringBuilder response = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
            }

            // Extract advice from JSON manually (quick and dirty)
            String full = response.toString();
            int start = full.indexOf(":\"") + 2;
            int end = full.lastIndexOf("\"");
            String advice = full.substring(start, end).replace("\\n", "\n");

            return advice;

        } catch (Exception e) {
            return "⚠️ Failed to fetch AI advice: " + e.getMessage();
        }
    }
}
