package src.module2_AI_Engine;

import java.util.Map;
import java.util.List;

public class AI_Engine {

    public void optimizePlan(Map<String, List<String>> plan, String difficultyLevel) {
        // Simulate optimization based on difficulty level
        if (difficultyLevel.equalsIgnoreCase("hard")) {
            System.out.println("AI Optimization: Increasing revision sessions for tough subjects...");
            for (String day : plan.keySet()) {
                plan.get(day).add(" - Revise key concepts");
            }
        } else if (difficultyLevel.equalsIgnoreCase("easy")) {
            System.out.println("AI Optimization: Light schedule generated for easy prep.");
        } else {
            System.out.println("AI Optimization: Balanced schedule with focused sessions.");
        }
    }
}
