package src.Module4_UI_Notifications;

import java.util.*;

public class Notification_Service {

    private List<String> notifications;

    public Notification_Service() {
        notifications = new ArrayList<>();
    }

    public void addReminder(String message) {
        notifications.add(message);
    }

    public void sendReminders() {
        System.out.println("\n🔔 Notifications:");
        if (notifications.isEmpty()) {
            System.out.println("No new notifications.");
        } else {
            for (String note : notifications) {
                System.out.println("👉 " + note);
            }
            notifications.clear(); // Clear after sending
        }
    }
}
