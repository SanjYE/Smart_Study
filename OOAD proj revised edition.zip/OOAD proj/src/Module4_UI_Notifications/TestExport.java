// package src.Module4_UI_Notifications;

// import java.util.*;

// public class TestExport {
//     public static void main(String[] args) {
//         Map<String, List<String>> plan = new LinkedHashMap<>();
//         plan.put("Monday", Arrays.asList("Revise OOP", "Practice 2 coding problems"));
//         plan.put("Tuesday", Arrays.asList("Read DBMS notes", "Watch YouTube lectures"));

//         Exporter exporter = new Exporter();
//         exporter.exportToPDF(plan);
//     }
// }

package src.Module4_UI_Notifications;

import src.module1_profile.Preferences;
import src.module1_profile.Student;

import java.util.*;

public class TestExport {
    public static void main(String[] args) {
        // Sample data for testing
        String name = "Shashank";
        String email = "shashank@example.com";
        String[] subjects = {"OOP", "DBMS"};
        int dailyHours = 3;
        String examDate = "2025-04-30";
        String difficulty = "medium";

        Student student = new Student(name, email);
        Preferences prefs = new Preferences(subjects, dailyHours, examDate, difficulty);
        student.setPreferences(prefs);

        Map<String, List<String>> plan = new LinkedHashMap<>();
        plan.put("Monday", Arrays.asList("Revise OOP", "Practice 2 coding problems"));
        plan.put("Tuesday", Arrays.asList("Read DBMS notes", "Watch YouTube lectures"));

        Exporter exporter = new Exporter();
        exporter.exportToBridgeFiles(student, plan); // ✅ correct method
    }
}
