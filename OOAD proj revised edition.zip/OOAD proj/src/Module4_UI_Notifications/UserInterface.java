package src.Module4_UI_Notifications;

import java.util.*;

public class UserInterface {

    public void displayStudyPlan(Map<String, List<String>> plan) {
        System.out.println("\n=== Your Study Plan ===");
        for (String day : plan.keySet()) {
            System.out.println(day + ":");
            for (String topic : plan.get(day)) {
                System.out.println("  - " + topic);
            }
        }
    }

    public void markTopicAsCompleted(Map<String, List<String>> plan, String day, String topic) {
        if (plan.containsKey(day) && plan.get(day).contains(topic)) {
            plan.get(day).remove(topic);
            System.out.println("Topic marked as completed: " + topic);
        } else {
            System.out.println("Topic not found in plan.");
        }
    }
}
